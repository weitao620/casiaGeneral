<template>
  <div id="app">
    <router-view v-if="isRouterAlive"/>
  </div>
</template>

<style lang="less">
  @import "./assets/css/base.less";
  #app {
    font-family: "Avenir", Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
  }
  #nav {
    padding: 30px;
  }

  #nav a {
    font-weight: bold;
    color: #2c3e50;
  }

  #nav a.router-link-exact-active {
    color: #42b983;
  }
</style>

<script>
import { mapMutations, mapGetters } from "vuex";
import Url from "@/assets/js/url.js";
export default {
  provide() {
    return {
      reload: this.reload
    };
  },
  data() {
    return {
      headShow: false,
      isRouterAlive: true
    };
  },

  methods: {
    reload() {
      this.isRouterAlive = false;
      this.$nextTick(function() {
        this.isRouterAlive = true;
      });
    },
    auth() {
      let that = this;
      if (this.$route.name == 'login') {
        return false
      }
      let param = {
        passport: JSON.parse(localStorage.getItem('userInfo')).passport
        // password: JSON.parse(localStorage.getItem('userInfo')).password
      }
      that.$http
        .get(Url + "/aimw/user/getAuthInfo", { params: param })
        .then(res => {
          var data = res.data;
          console.log(data)
          if (data.code == 0) {
            let obja = {
              menuAuthID: []
            }
            if (data.data.userAuth == '') {
              data.data.userAuth = JSON.stringify(obja)
            } else {
              if (JSON.parse(data.data.userAuth).menuAuthID) {
              } else {
                let nOb = JSON.parse(data.data.userAuth)
                nOb.menuAuthID = []
                data.data.userAuth = JSON.stringify(nOb)
              }
            }
            localStorage.setItem("userAuth", data.data.userAuth);
            localStorage.setItem("userType", 1);
            localStorage.setItem("algTypes", JSON.stringify(data.data.algTypes));
          } else {
            that.$message.error(data.msg);
          }
        })
        .catch(res => {
          console.log(res);
        });
    },
    ...mapMutations(["setUserName"])
  },
  mounted() {
    var user = sessionStorage.getItem("userName");
    if (user) {
      this.setUserName(user);
    }
    if (window.location.href.indexOf('details/report/') != -1) {
      console.log('不获取权限')
    } else {
      this.auth()
    }
    // if (this.$root._route.name === 'screenindex') {
    //   console.log('不获取权限')
    // } else {
    //   this.auth()
    // }
  },
  computed: {
    ...mapGetters(["getUserName"])
  }
};
</script>
